# alexa-skill-async-number
This is a Skill that once you provide a date or a number Alexa reads a fact about it
